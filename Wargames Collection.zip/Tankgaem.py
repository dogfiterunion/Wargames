import random, time, os

def play_tank_gaem():
    os.system('cls' if os.name == 'nt' else 'clear')
    print("\n--- tank gaem ---")
    print("(1) 1v1 | (2) vs AI | (3) Spectator | (4) Training | (5) Line Battle")
    mode = input("Select Mode: ")
    
    is_p1_ai, is_p2_ai = (mode in ['3','5']), (mode in ['2','3','5'])
    spec_mode, training, line_battle = (mode == '3'), (mode == '4'), (mode == '5')

    size = 20 if line_battle else 5
    grid = [['.' for _ in range(size)] for _ in range(size)]
    
    walls, rocks = (35, 20) if line_battle else (4, 2)
    for char, count in [('R', rocks), ('W', walls)]:
        for _ in range(count):
            while True:
                r, c = random.randint(0, size-1), random.randint(0, size-1)
                if grid[r][c] == '.' and (r,c) not in [(0,0), (size-1, size-1)]:
                    grid[r][c] = char; break

    tanks = {}
    if line_battle:
        tanks[0] = {'pos': [0, 0], 'hp': 20, 'team': 1, 'ai': False}
        for i in range(1, 5):
            tanks[i] = {'pos': [random.randint(0, 5), random.randint(0, 5)], 'hp': 20, 'team': 1, 'ai': True}
        for i in range(5, 10):
            tanks[i] = {'pos': [random.randint(14, 19), random.randint(14, 19)], 'hp': 20, 'team': 2, 'ai': True}
    else:
        tanks[0] = {'pos': [0, 0], 'hp': 20, 'team': 1, 'ai': is_p1_ai}
        tanks[1] = {'pos': [size-1, size-1], 'hp': 99 if training else 20, 'team': 2, 'ai': is_p2_ai}

    turn_num, log, kill_feed = 1, ["Battle Started!"], []
    tank_ids = sorted(list(tanks.keys()))
    curr_idx = 0

    def get_dmg():
        r = random.random()
        return (1, "Ricochet") if r < .2 else (4, "Light Hit") if r < .5 else (5, "Heavy Hit") if r < .8 else (20, "MAGAZINE SHOT")

    def add_kill(a, v):
        a_l = "1" if a == 0 else ("A" if tanks[a]['team'] == 1 else "B")
        v_l = "1" if v == 0 else ("A" if tanks[v]['team'] == 1 else "B")
        kill_feed.append(f" [ {a_l} -> {v_l} ] ")
        if len(kill_feed) > 3: kill_feed.pop(0)

    def can_see(r, c, v_pos):
        dr, dc = r - v_pos[0], c - v_pos[1]
        dist = max(abs(dr), abs(dc))
        if dist <= 2: return True
        sr, sc = dr/dist, dc/dist
        for i in range(1, dist):
            tr, tc = int(v_pos[0] + i*sr), int(v_pos[1] + i*sc)
            if grid[tr][tc] in ['R', 'W']: return False
        return True

    while True:
        t1_a = [id for id, t in tanks.items() if t['team'] == 1 and t['hp'] > 0]
        t2_a = [id for id, t in tanks.items() if t['team'] == 2 and t['hp'] > 0]
        if not t1_a or not t2_a:
            print(f"\nGAEM OVER! {'Team 1' if t1_a else 'Team 2'} wins!"); break

        tid = tank_ids[curr_idx]
        t_data = tanks[tid]
        if t_data['hp'] <= 0:
            curr_idx = (curr_idx + 1) % len(tank_ids); continue

        if 0 in tanks and tanks[0]['hp'] <= 0: spec_mode = True

        # Turn Optimization: Cache vis and tank positions
        tank_map = {tuple(t['pos']): id for id, t in tanks.items() if t['hp'] > 0}
        vis_cache = set()
        if not (spec_mode or training):
            for t_id in t1_a:
                tp = tanks[t_id]['pos']
                for r in range(size):
                    for c in range(size):
                        if (r,c) not in vis_cache and can_see(r, c, tp): vis_cache.add((r,c))

        os.system('cls' if os.name == 'nt' else 'clear')
        hud = f" {len(t1_a)} VS {len(t2_a)} "
        print(f"{' '*(size-len(hud)//2)}{hud}")
        for k in kill_feed: print(f"{' '*(size*2-len(k))}{k}")

        c_l = "1" if tid == 0 else ("A" if t_data['team'] == 1 else "B")
        print(f"--- TURN {turn_num} | Active: {c_l} ---")
        
        # Fast Render
        out = []
        for r in range(size):
            row = []
            for c in range(size):
                if spec_mode or training or (r,c) in vis_cache:
                    occ = tank_map.get((r,c))
                    row.append('1' if occ == 0 else 'A' if occ in t1_a else 'B' if occ is not None else grid[r][c])
                else: row.append('?')
            out.append(" ".join(row))
        print("\n".join(out) + "\n" + "-"*25 + "\nLOG:")
        for line in log[-5:]: print(f"> {line}")

        acted = False
        if t_data['ai']:
            time.sleep(0.01) # Ultra-fast AI processing
            for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                sr, sc = t_data['pos'][0]+dr, t_data['pos'][1]+dc
                while 0 <= sr < size and 0 <= sc < size:
                    target = tank_map.get((sr, sc))
                    if target is not None:
                        if tanks[target]['team'] != t_data['team']:
                            dmg, name = get_dmg()
                            tanks[target]['hp'] -= dmg
                            v_l = "1" if target == 0 else ("A" if tanks[target]['team'] == 1 else "B")
                            log.append(f"{c_l} shot {v_l}: {name}")
                            if tanks[target]['hp'] <= 0: add_kill(tid, target)
                            acted = True
                        break
                    elif grid[sr][sc] == 'W':
                        grid[sr][sc] = '.'; log.append(f"{c_l} broke wall"); acted = True; break
                    elif grid[sr][sc] == 'R': break
                    sr, sc = sr+dr, sc+dc
                if acted: break
            if not acted:
                d = random.choice([[-1,0],[1,0],[0,-1],[0,1]])
                nr, nc = t_data['pos'][0]+d[0], t_data['pos'][1]+d[1]
                if 0 <= nr < size and 0 <= nc < size and grid[nr][nc] == '.' and (nr,nc) not in tank_map:
                    t_data['pos'] = [nr, nc]
        else:
            cmd = input(f"Action (WASD/F+WASD): ").lower()
            if cmd.startswith('f') and len(cmd) > 1:
                dr, dc = {'w':(-1,0),'s':(1,0),'a':(0,-1),'d':(0,1)}.get(cmd[-1], (0,0))
                sr, sc = t_data['pos'][0]+dr, t_data['pos'][1]+dc
                while 0 <= sr < size and 0 <= sc < size:
                    target = tank_map.get((sr, sc))
                    if target is not None:
                        dmg, name = get_dmg()
                        tanks[target]['hp'] -= dmg
                        v_l = "A" if tanks[target]['team'] == 1 else "B"
                        log.append(f"1 HIT {v_l}: {name}")
                        if tanks[target]['hp'] <= 0: add_kill(tid, target)
                        break
                    elif grid[sr][sc] == 'W': grid[sr][sc] = '.'; log.append("Wall destroyed"); break
                    elif grid[sr][sc] == 'R': log.append("Hit Rock"); break
                    sr, sc = sr+dr, sc+dc
            elif cmd in 'wasd' and len(cmd) == 1:
                dr, dc = {'w':(-1,0),'s':(1,0),'a':(0,-1),'d':(0,1)}[cmd]
                nr, nc = t_data['pos'][0]+dr, t_data['pos'][1]+dc
                if 0 <= nr < size and 0 <= nc < size and grid[nr][nc] == '.' and (nr,nc) not in tank_map:
                    t_data['pos'] = [nr, nc]

        curr_idx = (curr_idx + 1) % len(tank_ids)
        turn_num += 1

if __name__ == "__main__":
    play_tank_gaem()